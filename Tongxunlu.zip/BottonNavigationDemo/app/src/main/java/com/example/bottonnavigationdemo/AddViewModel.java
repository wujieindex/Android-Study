package com.example.bottonnavigationdemo;

import androidx.lifecycle.ViewModel;

public class AddViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}