package com.example.bottonnavigationdemo;

import androidx.lifecycle.ViewModel;

public class StoreViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}