package com.example.bottonnavigationdemo;

import androidx.lifecycle.ViewModel;

public class VideoViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}